import express from 'express';
import { getAllPlayers, 
		getTopPerformers} 
		from '../controllers/playersController.js';

const router = express.Router();

// GET players and top performers routes
router.get('/players', getAllPlayers);
router.get('/top-performers', getTopPerformers);

export default router;